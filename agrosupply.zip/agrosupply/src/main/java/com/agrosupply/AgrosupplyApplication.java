package com.agrosupply;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties
public class AgrosupplyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgrosupplyApplication.class, args);
	}

}
