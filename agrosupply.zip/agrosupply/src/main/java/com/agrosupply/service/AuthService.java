package com.agrosupply.service;

import com.agrosupply.dto.request.LoginRequest;
import com.agrosupply.dto.request.RegisterRequest;
import com.agrosupply.dto.response.AuthResponse;
import com.agrosupply.entity.User;
import com.agrosupply.enums.Role;
import com.agrosupply.enums.UserStatus;
import com.agrosupply.exception.BadRequestException;
import com.agrosupply.exception.UnauthorizedException;
import com.agrosupply.repository.UserRepository;
import com.agrosupply.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthResponse register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered");
        }

        UserStatus initialStatus = (request.getRole() == Role.FARMER)
                ? UserStatus.ACTIVE
                : UserStatus.PENDING;

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .location(request.getLocation())
                .role(request.getRole())
                .status(initialStatus)
                .build();

        User savedUser = userRepository.save(user);

        // Only generate token for ACTIVE users (farmers)
        // Staff roles get null token — they must wait for admin approval
        String token = null;
        if (initialStatus == UserStatus.ACTIVE) {
            token = jwtUtil.generateToken(savedUser.getEmail());
        }

        String message = (initialStatus == UserStatus.ACTIVE)
                ? "Registration successful"
                : "Registration successful. Awaiting admin approval.";

        return AuthResponse.builder()
                .token(token)
                .name(savedUser.getName())
                .email(savedUser.getEmail())
                .role(savedUser.getRole())
                .status(savedUser.getStatus())
                .message(message)
                .build();
    }

    public AuthResponse login(LoginRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UnauthorizedException("Invalid email or password"));

        if (user.getStatus() == UserStatus.PENDING) {
            throw new UnauthorizedException("Your account is pending admin approval");
        }

        if (user.getStatus() == UserStatus.INACTIVE) {
            throw new UnauthorizedException("Your account has been deactivated. Contact admin.");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new UnauthorizedException("Invalid email or password");
        }

        String token = jwtUtil.generateToken(user.getEmail());

        return AuthResponse.builder()
                .token(token)
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .status(user.getStatus())
                .message("Login successful")
                .build();
    }
}
