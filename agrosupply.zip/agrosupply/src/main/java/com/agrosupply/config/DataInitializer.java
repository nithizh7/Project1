package com.agrosupply.config;

import com.agrosupply.entity.User;
import com.agrosupply.enums.Role;
import com.agrosupply.enums.UserStatus;
import com.agrosupply.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {

        if (!userRepository.existsByEmail("admin@agrosupply.com")) {

            User admin = User.builder()
                    .name("Admin")
                    .email("admin@agrosupply.com")
                    .password(passwordEncoder.encode("admin123"))  
                    .phone("0000000000")
                    .role(Role.ADMIN)
                    .status(UserStatus.ACTIVE)
                    .build();

            userRepository.save(admin);
            System.out.println("✅ Admin created — email: admin@agrosupply.com | password: admin123");
        } else {
            System.out.println("✅ Admin already exists — skipping creation");
        }
    }
}