package com.agrosupply.controller;

import com.agrosupply.dto.request.SupplierOrderRequest;
import com.agrosupply.dto.response.SupplierOrderResponse;
import com.agrosupply.enums.OrderStatus;
import com.agrosupply.service.SupplierOrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/supplier-orders")
@RequiredArgsConstructor
public class SupplierOrderController {

    private final SupplierOrderService supplierOrderService;

    @PostMapping
    @PreAuthorize("hasRole('PROCUREMENT')")
    public ResponseEntity<SupplierOrderResponse> createOrder(@Valid @RequestBody SupplierOrderRequest request) {
        return ResponseEntity.ok(supplierOrderService.createOrder(request));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','PROCUREMENT')")
    public ResponseEntity<List<SupplierOrderResponse>> getAllOrders() {
        return ResponseEntity.ok(supplierOrderService.getAllOrders());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','PROCUREMENT')")
    public ResponseEntity<SupplierOrderResponse> getOrderById(@PathVariable Long id) {
        return ResponseEntity.ok(supplierOrderService.getOrderById(id));
    }

    @GetMapping("/officer/{officerId}")
    @PreAuthorize("hasAnyRole('ADMIN','PROCUREMENT')")
    public ResponseEntity<List<SupplierOrderResponse>> getOrdersByOfficer(@PathVariable Long officerId) {
        return ResponseEntity.ok(supplierOrderService.getOrdersByOfficer(officerId));
    }

    @GetMapping("/filter")
    @PreAuthorize("hasAnyRole('ADMIN','PROCUREMENT')")
    public ResponseEntity<List<SupplierOrderResponse>> getOrdersByStatus(@RequestParam OrderStatus status) {
        return ResponseEntity.ok(supplierOrderService.getOrdersByStatus(status));
    }

    @PatchMapping("/{id}/deliver")
    @PreAuthorize("hasRole('PROCUREMENT')")
    public ResponseEntity<SupplierOrderResponse> markDelivered(@PathVariable Long id,
                                                                @RequestParam Long warehouseId) {
        return ResponseEntity.ok(supplierOrderService.markDelivered(id, warehouseId));
    }

    @PatchMapping("/{id}/cancel")
    @PreAuthorize("hasRole('PROCUREMENT')")
    public ResponseEntity<SupplierOrderResponse> cancelOrder(@PathVariable Long id) {
        return ResponseEntity.ok(supplierOrderService.cancelOrder(id));
    }
}