package com.agrosupply.controller;

import com.agrosupply.dto.request.PayRequest;
import com.agrosupply.dto.response.InvoiceResponse;
import com.agrosupply.enums.InvoiceStatus;
import com.agrosupply.service.InvoiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','PROCUREMENT')")
    public ResponseEntity<List<InvoiceResponse>> getAllInvoices() {
        return ResponseEntity.ok(invoiceService.getAllInvoices());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','FARMER','PROCUREMENT')")
    public ResponseEntity<InvoiceResponse> getInvoiceById(@PathVariable Long id) {
        return ResponseEntity.ok(invoiceService.getInvoiceById(id));
    }

    @GetMapping("/farmer/{farmerId}")
    @PreAuthorize("hasAnyRole('ADMIN','FARMER')")
    public ResponseEntity<List<InvoiceResponse>> getInvoicesByFarmer(@PathVariable Long farmerId) {
        return ResponseEntity.ok(invoiceService.getInvoicesByFarmer(farmerId));
    }

    @GetMapping("/filter")
    @PreAuthorize("hasAnyRole('ADMIN','PROCUREMENT')")
    public ResponseEntity<List<InvoiceResponse>> getInvoicesByStatus(
            @RequestParam InvoiceStatus status) {
        return ResponseEntity.ok(invoiceService.getInvoicesByStatus(status));
    }

    @PatchMapping("/{id}/pay")
    @PreAuthorize("hasRole('FARMER')")
    public ResponseEntity<InvoiceResponse> payInvoice(@PathVariable Long id,
                                                       @Valid @RequestBody PayRequest request) {
        return ResponseEntity.ok(invoiceService.payInvoice(id, request));
    }
}