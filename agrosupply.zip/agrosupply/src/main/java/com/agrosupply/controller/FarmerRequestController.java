package com.agrosupply.controller;

import com.agrosupply.dto.request.FarmerRequestRequest;
import com.agrosupply.dto.response.FarmerRequestResponse;
import com.agrosupply.enums.RequestStatus;
import com.agrosupply.service.FarmerRequestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/requests")
@RequiredArgsConstructor
public class FarmerRequestController {

    private final FarmerRequestService farmerRequestService;

    @PostMapping
    @PreAuthorize("hasRole('FARMER')")
    public ResponseEntity<FarmerRequestResponse> createRequest(
            @Valid @RequestBody FarmerRequestRequest request) {
        return ResponseEntity.ok(farmerRequestService.createRequest(request));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ResponseEntity<List<FarmerRequestResponse>> getAllRequests() {
        return ResponseEntity.ok(farmerRequestService.getAllRequests());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE','FARMER','DELIVERY')")
    public ResponseEntity<FarmerRequestResponse> getRequestById(@PathVariable Long id) {
        return ResponseEntity.ok(farmerRequestService.getRequestById(id));
    }

    @GetMapping("/farmer/{farmerId}")
    @PreAuthorize("hasAnyRole('ADMIN','FARMER')")
    public ResponseEntity<List<FarmerRequestResponse>> getRequestsByFarmer(
            @PathVariable Long farmerId) {
        return ResponseEntity.ok(farmerRequestService.getRequestsByFarmer(farmerId));
    }

    @GetMapping("/agent/{agentId}")
    @PreAuthorize("hasAnyRole('ADMIN','DELIVERY')")
    public ResponseEntity<List<FarmerRequestResponse>> getRequestsByAgent(
            @PathVariable Long agentId) {
        return ResponseEntity.ok(farmerRequestService.getRequestsByAgent(agentId));
    }

    @GetMapping("/filter")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ResponseEntity<List<FarmerRequestResponse>> getRequestsByStatus(
            @RequestParam RequestStatus status) {
        return ResponseEntity.ok(farmerRequestService.getRequestsByStatus(status));
    }

    @PatchMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('ADMIN','FARMER')")
    public ResponseEntity<FarmerRequestResponse> cancelRequest(@PathVariable Long id) {
        return ResponseEntity.ok(farmerRequestService.cancelRequest(id));
    }
}