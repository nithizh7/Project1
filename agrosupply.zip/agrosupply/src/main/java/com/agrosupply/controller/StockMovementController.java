package com.agrosupply.controller;

import com.agrosupply.dto.request.StockTransferRequest;
import com.agrosupply.dto.response.StockMovementResponse;
import com.agrosupply.enums.StockMovementStatus;
import com.agrosupply.service.StockMovementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stock-movements")
@RequiredArgsConstructor
public class StockMovementController {

    private final StockMovementService stockMovementService;

    @PostMapping("/transfer")
    @PreAuthorize("hasRole('WAREHOUSE')")
    public ResponseEntity<StockMovementResponse> requestTransfer(
            @Valid @RequestBody StockTransferRequest request) {
        return ResponseEntity.ok(stockMovementService.requestTransfer(request));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ResponseEntity<List<StockMovementResponse>> getAllMovements() {
        return ResponseEntity.ok(stockMovementService.getAllMovements());
    }

    @GetMapping("/filter")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ResponseEntity<List<StockMovementResponse>> getByStatus(
            @RequestParam StockMovementStatus status) {
        return ResponseEntity.ok(stockMovementService.getMovementsByStatus(status));
    }

    @GetMapping("/incoming/{warehouseId}")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ResponseEntity<List<StockMovementResponse>> getIncomingTransfers(
            @PathVariable Long warehouseId) {
        return ResponseEntity.ok(stockMovementService.getIncomingTransfers(warehouseId));
    }

    @GetMapping("/outgoing/{warehouseId}")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ResponseEntity<List<StockMovementResponse>> getOutgoingTransfers(
            @PathVariable Long warehouseId) {
        return ResponseEntity.ok(stockMovementService.getOutgoingTransfers(warehouseId));
    }

    @PatchMapping("/{id}/approve")
    @PreAuthorize("hasRole('WAREHOUSE')")
    public ResponseEntity<StockMovementResponse> approveTransfer(@PathVariable Long id) {
        return ResponseEntity.ok(stockMovementService.approveTransfer(id));
    }

    @PatchMapping("/{id}/reject")
    @PreAuthorize("hasRole('WAREHOUSE')")
    public ResponseEntity<StockMovementResponse> rejectTransfer(@PathVariable Long id) {
        return ResponseEntity.ok(stockMovementService.rejectTransfer(id));
    }
}