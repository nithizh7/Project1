package com.agrosupply.controller;

import com.agrosupply.dto.response.DeliveryResponse;
import com.agrosupply.enums.DeliveryStatus;
import com.agrosupply.service.DeliveryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/deliveries")
@RequiredArgsConstructor
public class DeliveryController {

    private final DeliveryService deliveryService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<DeliveryResponse>> getAllDeliveries() {
        return ResponseEntity.ok(deliveryService.getAllDeliveries());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','DELIVERY')")
    public ResponseEntity<DeliveryResponse> getDeliveryById(@PathVariable Long id) {
        return ResponseEntity.ok(deliveryService.getDeliveryById(id));
    }

    @GetMapping("/agent/{agentId}")
    @PreAuthorize("hasAnyRole('ADMIN','DELIVERY')")
    public ResponseEntity<List<DeliveryResponse>> getDeliveriesByAgent(@PathVariable Long agentId) {
        return ResponseEntity.ok(deliveryService.getDeliveriesByAgent(agentId));
    }

    @GetMapping("/filter")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ResponseEntity<List<DeliveryResponse>> getDeliveriesByStatus(
            @RequestParam DeliveryStatus status) {
        return ResponseEntity.ok(deliveryService.getDeliveriesByStatus(status));
    }

    @PatchMapping("/{id}/complete")
    @PreAuthorize("hasRole('DELIVERY')")
    public ResponseEntity<DeliveryResponse> completeDelivery(@PathVariable Long id) {
        return ResponseEntity.ok(deliveryService.completeDelivery(id));
    }
}